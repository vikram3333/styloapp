

package com.ibm.mobileappbuilder.storecatalog20150911132549.ui;

import android.os.Bundle;

import com.ibm.mobileappbuilder.storecatalog20150911132549.R;

import java.util.ArrayList;
import java.util.List;

import ibmmobileappbuilder.MenuItem;

import static ibmmobileappbuilder.analytics.injector.PageViewBehaviorInjector.pageViewBehavior;

/**
 * FootwearFragment menu fragment.
 */
public class FootwearFragment extends ibmmobileappbuilder.ui.MenuFragment {

    /**
     * Default constructor
     */
    public FootwearFragment(){
        super();
    }

    // Factory method
    public static FootwearFragment newInstance(Bundle args) {
        FootwearFragment fragment = new FootwearFragment();

        fragment.setArguments(args);
        return fragment;
    }

    @Override
      public void onCreate(Bundle savedInstanceState) {
          super.onCreate(savedInstanceState);
          addBehavior(pageViewBehavior("footwear"));
      }

    // Menu Fragment interface
    @Override
    public List<MenuItem> getMenuItems() {
        ArrayList<MenuItem> items = new ArrayList<MenuItem>();
        return items;
    }

    @Override
    public int getLayout() {
        return R.layout.fragment_list;
    }

    @Override
    public int getItemLayout() {
        return R.layout.footwear_item;
    }
}

