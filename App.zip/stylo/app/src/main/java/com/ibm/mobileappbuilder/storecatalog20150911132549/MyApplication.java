

package com.ibm.mobileappbuilder.storecatalog20150911132549;

import android.app.Application;
import ibmmobileappbuilder.injectors.ApplicationInjector;
import android.support.multidex.MultiDexApplication;
import ibmmobileappbuilder.analytics.injector.AnalyticsReporterInjector;
import ibmmobileappbuilder.cloudant.factory.CloudantDatabaseSyncerFactory;
import java.net.URI;


/**
 * You can use this as a global place to keep application-level resources
 * such as singletons, services, etc.
 */
public class MyApplication extends MultiDexApplication {

    @Override
    public void onCreate() {
        super.onCreate();
        ApplicationInjector.setApplicationContext(this);
        AnalyticsReporterInjector.analyticsReporter(this).init(this);
        //Syncing cloudant ds
        CloudantDatabaseSyncerFactory.instanceFor(
            "stylo",
            URI.create("https://12070992-5c01-4d3b-96b3-e02869a2d4cb-bluemix:f4462483c243828b5e2ca2a534f66ae7636eaff9b3736179b3f8d48648a1f0dd@12070992-5c01-4d3b-96b3-e02869a2d4cb-bluemix.cloudant.com/stylo")
        ).sync(null);
      }
}

