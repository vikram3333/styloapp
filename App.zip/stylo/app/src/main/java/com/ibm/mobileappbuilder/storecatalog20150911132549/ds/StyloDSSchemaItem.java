
package com.ibm.mobileappbuilder.storecatalog20150911132549.ds;
import java.util.Date;

import ibmmobileappbuilder.mvp.model.MutableIdentifiableBean;

import android.os.Parcel;
import android.os.Parcelable;
import com.google.gson.annotations.SerializedName;

public class StyloDSSchemaItem implements Parcelable, MutableIdentifiableBean {

    private transient String cloudantIdentifiableId;

    @SerializedName("name") public String name;
    @SerializedName("email") public String email;
    @SerializedName("phone") public String phone;
    @SerializedName("org") public String org;
    @SerializedName("rating") public Date rating;
    @SerializedName("comments") public String comments;

    @Override
    public void setIdentifiableId(String id) {
        this.cloudantIdentifiableId = id;
    }

    @Override
    public String getIdentifiableId() {
        return cloudantIdentifiableId;
    }

    @Override
    public int describeContents() {
        return 0;
    }

    @Override
    public void writeToParcel(Parcel dest, int flags) {
        dest.writeString(cloudantIdentifiableId);
        dest.writeString(name);
        dest.writeString(email);
        dest.writeString(phone);
        dest.writeString(org);
        dest.writeValue(rating != null ? rating.getTime() : null);
        dest.writeString(comments);
    }

    public static final Creator<StyloDSSchemaItem> CREATOR = new Creator<StyloDSSchemaItem>() {
        @Override
        public StyloDSSchemaItem createFromParcel(Parcel in) {
            StyloDSSchemaItem item = new StyloDSSchemaItem();
            item.cloudantIdentifiableId = in.readString();

            item.name = in.readString();
            item.email = in.readString();
            item.phone = in.readString();
            item.org = in.readString();
            Long ratingAux = (Long) in.readValue(null);
            item.rating = ratingAux != null ? new Date(ratingAux) : null;
            item.comments = in.readString();
            return item;
        }

        @Override
        public StyloDSSchemaItem[] newArray(int size) {
            return new StyloDSSchemaItem[size];
        }
    };
}


